 Created by: BearFather
 Editied by: PrimalStage

-- INSTRUCTIONS -- 

Place the "StarScreenShots" folder into which ever folder you want to place the program

In the "ExtraLinks" folder, Run the "randomscspalsh.ps1" File with powershell (right click) You only need to do this once

Let the program run, it will tell you what it is doing as it goes

You should see that the "RSI Launcher (BETA)" app has apeard on your desktop, and that your RSI launcher is open.






 -- ISSUES? --

Please DM "primal_stage" if you have an issues.